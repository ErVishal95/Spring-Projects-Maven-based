package Modal_TaxInvoice;

import java.util.Date;

public class Customer {
	private String name;
	private String email;
	private String address;
	private static String purchaseDate;
	private String mobNum;
	
	
	public String getMobNum() {
		return mobNum;
	}
	public void setMobNum(String mobNum) {
		this.mobNum = mobNum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public Customer(String name, String email, String address, String purchaseDate, String mobNum) {
		super();
		this.name = name;
		this.email = email;
		this.address = address;
		this.purchaseDate = purchaseDate;
		this.mobNum = mobNum;
	}
	
}
