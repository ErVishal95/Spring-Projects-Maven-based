package com.vishal;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/reservation")
@Controller
public class ReservationController {

		@RequestMapping("/bookingForm")
		public String bookingForm(Model m){
			Reservation rs = new Reservation();
			m.addAttribute("reservation", rs);
			return "reservation-page";
		}
		
		@RequestMapping("/submitForm")
		//@ModelAttribute("reservation") binds form data to beans object.
		public String submitForm(@ModelAttribute("reservation") Reservation rs){
			return "confirmation-form";
		}
}
