package com.vishal.SpringAnnotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component          // This Annotation provides the object of class (No need of New Keyword here), used along @Configuration Annotation //
public class Samsung 
{	
	@Autowired 				// This Annotation wired(provide) the object by automatically searching the object when placed over Type/Name/Constructor/Setter Mathod 
	//@Qualifier("mediaTek")
	@Qualifier("snapDragon")    // This Annotation provide more control on among all spring beans (implementing same interface) the specified should be given preference and remove conflicts  //
	MobileProcessor cpu;
	
	public MobileProcessor getCpu() {
		return cpu;
	}

	public void setCpu(MobileProcessor cpu) {
		this.cpu = cpu;
	}

	public void config(){
		System.out.println("Octa Core, 4 GB RAM, 12 MP Camara");
		cpu.process();
	}
}
