package Service_TaxInvoice;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import com.itextpdf.text.log.SysoCounter;

import Modal_TaxInvoice.*;

public class Service_TaxInvoiceImpl implements Service_TaxInvoice{
	
	
	 private static List<Product> product;
	// private static List<Customer> customer;
	 private static Customer customer;
	 private static List<Sale> sale;
	 private static TaxInvoice invoice;
	// private static List<TaxInvoice> invoice;
	
	 static{
	        product= productDummyData();
	        customer= customerDummyData();
	        sale= saleDummyData();
	       // invoice= invoiceDummyData();
	        invoice= invoiceDummyData(product);
	    }
	 
	 
	@Override
	public void saveData() {
		// TODO Auto-generated method stub
		
	}


	/*public static List<TaxInvoice> invoiceDummyData() {
		final AtomicLong counter = new AtomicLong();
		List<TaxInvoice> taxInvoice = new ArrayList<TaxInvoice>();
		TaxInvoice taxInv = new TaxInvoice();
		taxInv.setInvoiceNum("000"+counter);
		taxInv.setInvoiceDate(new Product().getSaleDate());
		taxInv.getSubTotal();
		taxInv.getDiscount();
		taxInv.getCgstax();
		taxInv.getSgstax();
		taxInvoice.add(taxInv);
		return taxInvoice;
	}*/
	/*public static TaxInvoice invoiceDummyData() {
		final AtomicLong counter = new AtomicLong();
		counter.getAndIncrement();
		
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String strDate= formatter.format(date);
		//System.out.println(strDate);
		TaxInvoice taxInv = new TaxInvoice();
		taxInv.setInvoiceNum("000"+counter);
		taxInv.setInvoiceDate(strDate);
		taxInv.getSubTotal();
		taxInv.getDiscount();
		taxInv.getCgstax();
		taxInv.getSgstax();
		taxInv.g_Total();
		//taxInvoice.add(taxInv);
		return taxInv;
	}*/
	
	public static TaxInvoice invoiceDummyData(List<Product> list) {
		final AtomicLong counter = new AtomicLong();
		counter.getAndIncrement();
		float subTotal=0;
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String strDate= formatter.format(date);
		//System.out.println(strDate);
		TaxInvoice taxInv = new TaxInvoice();
		taxInv.setInvoiceNum("000"+counter);
		taxInv.setInvoiceDate(strDate);
		
		for(Product prd: list){
		//taxInv.getSubTotal(p.getAmount());
			subTotal+= prd.getAmount();
			System.out.println(prd.getAmount()+" Total: "+subTotal);
			
		/*taxInv.setSubTotal(subTotal);*/
		}
		taxInv.setSubTotal(subTotal);
		taxInv.getDiscount();
		taxInv.getCgstax();
		taxInv.getSgstax();
		taxInv.g_Total();
		//taxInvoice.add(taxInv);
		return taxInv;
	}


	public static List<Sale> saleDummyData() {
		// TODO Auto-generated method stub
		return null;
	}


	/*public static List<Customer> customerDummyData() {
		List<Customer> customer = new ArrayList<Customer>();
		customer.add(new Customer("Vishal", "vishal.verma@newgen.co.in", "Delhi", new Product().getSaleDate(),1122334455));
		return customer;
	}*/
	public static Customer customerDummyData() {
		//Customer customer = new Customer();
		//return new Customer("Vishal", "vishal.verma@newgen.co.in", "Delhi", invoice.getInvoiceDate(),"1122334455");
		return new Customer("Vishal", "vishal.verma@newgen.co.in", "Delhi", new Product().getSaleDate(),"1122334455");
	}


	public static List<Product> productDummyData() {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String strDate= formatter.format(date);
		//System.out.println(strDate);
		List<Product> product = new ArrayList<Product>();
		product.add(new Product("Ltes check it first", "HSN001", 22.0, 20.2,  strDate));
		product.add(new Product("Ltes check it second", "HSN002", 32.0, 30.2, strDate));
		product.add(new Product("Ltes check it third", "HSN003", 42.0, 40.2,  strDate));
		product.add(new Product("Ltes check it fourth", "HSN004", 52.0, 50.2, strDate));
		product.add(new Product("Ltes check it fifth", "HSN005", 62.0, 60.2,  strDate));
		/*product.add(new Product("Ltes check it first", "HSN001", 22.0, 20.2, 2250.0, invoice.getInvoiceDate()));
		product.add(new Product("Ltes check it second", "HSN002", 32.0, 30.2, 3250.0, invoice.getInvoiceDate()));
		product.add(new Product("Ltes check it third", "HSN003", 42.0, 40.2, 4250.0, invoice.getInvoiceDate()));
		product.add(new Product("Ltes check it fourth", "HSN004", 52.0, 50.2, 5250.0, invoice.getInvoiceDate()));
		product.add(new Product("Ltes check it fifth", "HSN005", 62.0, 60.2, 6250.0, invoice.getInvoiceDate()));*/
		return product;
	}
	
}
