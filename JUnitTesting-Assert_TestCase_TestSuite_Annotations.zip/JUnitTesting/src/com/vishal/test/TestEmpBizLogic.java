package com.vishal.test;

import org.junit.Test;

import com.vishal.src.EmpBuzLogic;
import com.vishal.src.Employee;

import static org.junit.Assert.*;

public class TestEmpBizLogic {
	Employee emp = new Employee();
	EmpBuzLogic ebl = new EmpBuzLogic();
	
	@Test
	public void testAnualsalary(){
		emp.setEmpId(100);
		emp.setName("vihan");
		emp.setSalary(10000);
		
		System.out.println("AnualSalary is "+ebl.calculateAnualSalary(emp));
		double salary = ebl.calculateAnualSalary(emp);
		assertEquals(120000, salary, 0.0);
	}
	
	@Test
	public void testApprasal(){
		emp.setEmpId(100);
		emp.setName("vihan");
		emp.setSalary(1000);
		
		System.out.println("Apprasal is "+ebl.calculateApprasal(emp));
		System.out.println();
		double apprasal = ebl.calculateApprasal(emp);
		assertEquals(1000, apprasal, 0.0);
	}
	
	@Test
	public void testAssertMethods(){
		String str1 = new String ("abc");
	      String str2 = new String ("abc");
	      String str3 = null;
	      String str4 = "abc";
	      String str5 = "abc";
			
	      int val1 = 5;
	      int val2 = 6;

	      String[] expectedArray = {"one", "two", "three"};
	      String[] resultArray =  {"one", "two", "three"};
	      
	      assertEquals(str1, str2);
	      assertNull(str3);
	      assertNotNull(str1);
	      assertFalse(val1==val2);
	      assertTrue(val1<val2);
	      assertSame(str4, str5);
	      assertNotSame(str4, str3);
	      assertArrayEquals(expectedArray, resultArray);
	}
}
