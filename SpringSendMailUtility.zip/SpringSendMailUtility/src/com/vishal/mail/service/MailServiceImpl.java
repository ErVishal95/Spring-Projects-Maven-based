package com.vishal.mail.service;

import java.io.File;
import java.io.IOException;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMailMessage;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.vishal.mail.bean.Mail;

@Service("mailService")
public class MailServiceImpl implements MailService{
	@Autowired
	JavaMailSender javaMailSender;
	
	@Override
	public void sendEmail(Mail mail) {
		MimeMessage mimeMessage= javaMailSender.createMimeMessage();
		try{
			MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);
			
			mimeMessageHelper.setSubject(mail.getMailSubject());
			mimeMessageHelper.setFrom(mail.getMailFrom());
			mimeMessageHelper.setTo(mail.getMailTo());
			mimeMessageHelper.setText(mail.getMailContent());
			
			System.out.println("Inside MailService Class");
			System.out.println(mail.getMailSubject());
			System.out.println(mail.getMailFrom());
			System.out.println(mail.getMailTo());
			System.out.println(mail.getMailContent());
			
			FileSystemResource file = new FileSystemResource("D:/testfile.pdf");
			mimeMessageHelper.addAttachment(file.getFilename(), file);
			System.out.println(file.getFilename());
			/*for(Object attachment : mail.getAttachments()){
				//File file= ((ClassPathResource)attachment).getFile();
				FileSystemResource file = new FileSystemResource("D:/testfile.pdf");
				mimeMessageHelper.addAttachment(file.getFilename(), file);
				System.out.println(file.getFilename());
			}*/
			
			javaMailSender.send(mimeMessageHelper.getMimeMessage());
		}catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
