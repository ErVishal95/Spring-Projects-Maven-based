package Serialization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DesirializationImpl {

	public static void main(String[] args) {
		Test test= null;
		
		try {
			FileInputStream fin = new FileInputStream("D://newfile.txt");
			ObjectInputStream oin=  new ObjectInputStream(fin);
			test= (Test)oin.readObject();
			oin.close();
			fin.close();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			
			System.out.println("Test class not found");
			e.printStackTrace();
		}
		System.out.println("Desirialising process...");
		System.out.println("First Name: "+test.firstName);
		System.out.println("Last Name: "+test.lastNama);
		System.out.println("Value 1: "+test.val1);
		System.out.println("Value 2: "+test.val2);
		System.out.println("Value 3: "+test.val3);
		
	}
}
