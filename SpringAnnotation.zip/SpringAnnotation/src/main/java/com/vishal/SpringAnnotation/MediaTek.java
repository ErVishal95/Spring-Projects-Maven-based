package com.vishal.SpringAnnotation;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component			 // This Annotation provides the object of class (No need of New Keyword here), used along @Configuration Annotation //
//@Primary			 // This Annotation removes the conflict of which class object to choose by making this class object primary when two different class object have same TYPE (implemented Interface)
public class MediaTek implements MobileProcessor {

	public void process() {
		System.out.println("2nd Best CPU");

	}

}
