package com.vishal.src;

import java.util.LinkedList;
import java.util.List;

public class CheckVowels {
	
	public static char[] checkVowels(char ss[]){
		char[] vowels= new char[ss.length];
		char[] consonents= new char[ss.length];
		if(ss.toString().isEmpty()){
			System.out.println("String is blank");
		}
		else{
			for(int i=0; i<ss.length; i++){
				if(ss[i]=='a' ||ss[i]=='e' ||ss[i]=='i' ||ss[i]=='o' ||ss[i]=='u')
					vowels[i]= ss[i];
				else{
					if(ss[i]==' ')
						continue;
					else
						consonents[i]= ss[i];
				}
			}
			System.out.print("Vowels are: ");
			for(int i=0; i<vowels.length; i++){
				System.out.print(vowels[i]);
			}
			System.out.println(" Vowel Array size "+vowels.length);
			System.out.println();
			
			System.out.print("consonents are: ");
			for(int i=0; i<consonents.length; i++){
				System.out.print(consonents[i]);
			}
			System.out.println(" consonents Array size "+consonents.length);
			System.out.println();
			}
		
		return ss;
	}
	
	public static List checkVowelUsingList(char ss[]){
		List vowel= new LinkedList<Character>();
		List consonent= new LinkedList<Character>();
		List arrlist= new LinkedList<Character>();
		if(ss.toString().isEmpty()){
			System.out.println("String is blank");
		}
		else{
			for(int i=0; i<ss.length; i++){
				if(ss[i]=='a' ||ss[i]=='e' ||ss[i]=='i' ||ss[i]=='o' ||ss[i]=='u')
					vowel.add(ss[i]);	
				else{
					if(ss[i]==' ')
						continue;
					else
						consonent.add(ss[i]);
				}
			}
			System.out.println("Vowels are: "+vowel+ " List size is "+vowel.size());
			System.out.println("consonents are: "+consonent+ " List size is "+consonent.size());
		}
		arrlist.addAll(vowel);
		arrlist.addAll(consonent);
		
		return arrlist;
	}
	
	public static void main(String[] args) {
		String s="Qwerty data lets check vowels";
		char[] ss= s.toCharArray();
		char[] string_charactors = checkVowels(ss);
		System.out.println(string_charactors);
		System.out.println(string_charactors.length);
		System.out.println();
		
		List<Character> list= checkVowelUsingList(ss);
		System.out.println(list);
		System.err.println("List Size is "+list.size());
	}
}
