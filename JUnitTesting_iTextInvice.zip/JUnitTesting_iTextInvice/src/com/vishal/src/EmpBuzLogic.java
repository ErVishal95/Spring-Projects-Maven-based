package com.vishal.src;

public class EmpBuzLogic {
	public double calculateAnualSalary(Employee emp){
		double anualSalary = 0.0;
		if(emp.getSalary()<=0){
			System.out.println("Can't calculate salary, entered amount is  "+emp.getSalary());
		}
		else{
		anualSalary = emp.getSalary()*12.0;
		}
		return anualSalary;
	}
	
	public double calculateApprasal(Employee emp){
		double apprasalAmt = 0.0;
		if(emp.getSalary()<=0){
			System.out.println("Can't calculate Apprasal");
		}
		else{
			if(emp.getSalary()<=2000)
				apprasalAmt = 1000.0;
			else
				apprasalAmt = 2000.0;
		}
		return apprasalAmt;
	}
}
