package com.vishal.SpringAnnotation;

public interface MobileProcessor 
{
	void process();
}
