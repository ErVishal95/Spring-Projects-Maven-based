package com.vishal.SpringAnnotation;

import org.springframework.stereotype.Component;

@Component					 // This Annotation provides the object of class (No need of New Keyword here), used along @Configuration Annotation //
public class SnapDragon implements MobileProcessor{
	
		public void process(){
			System.out.println("Worlds best prrocessor");
		}
}
