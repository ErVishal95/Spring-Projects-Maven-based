package com.vishal.mail.test;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.vishal.mail.bean.Mail;
import com.vishal.mail.configuration.ApplicationConfig;
import com.vishal.mail.service.MailService;

public class App {
	public static void main(String[] args) {
		Mail mail = new Mail();
		
		mail.setMailFrom("***********@gmail.com");
		mail.setMailTo("***********@gmail.com");
		mail.setMailSubject("**** *****");
		mail.setMailContent("Thanks for looking for the services with us.\n We request you to visit us again.!!");
		
		//List<Object> attachment = new ArrayList<Object>();
		AbstractApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		MailService mailService = (MailService)context.getBean("mailService");
		mailService.sendEmail(mail);
		System.out.println("Mail Sent");
		context.close();
	}
}
