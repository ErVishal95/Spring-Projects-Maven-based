package MultiThreading;

class IntTable{
//Synchronized method Example
	synchronized static protected void printTable(int n){
		for(int i=1; i<=3;i++){
			System.out.println(n*i);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

class Thread1 extends Thread{
	public void run(){
		IntTable.printTable(2);
	}
}

class Thread2 extends Thread{
	public void run(){
		IntTable.printTable(5);
	}
}

class Thread3 extends Thread{
	public void run(){
		IntTable.printTable(10);
	}
}

class MultiThreadClass{
	public static void multiThread() {
		
		Thread t1 = new Thread(){
				public void run(){
					IntTable.printTable(1);
				}
			};
		Thread t2 = new Thread(){
			public void run(){
				IntTable.printTable(13);
			}
		};
		
		t1.start();
		t2.start();
	}
	
}

public class StaticSynchronizationExmple {
	public static void main(String[] args) {
		Thread1 t1= new Thread1();
		Thread2 t2= new Thread2();
		Thread3 t3= new Thread3();
		
		t1.start();
		t2.start();
		t3.start();
		
		MultiThreadClass.multiThread();
	}
}
