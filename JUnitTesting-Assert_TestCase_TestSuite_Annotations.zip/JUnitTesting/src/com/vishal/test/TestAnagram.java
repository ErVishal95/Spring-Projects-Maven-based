package com.vishal.test;

import java.util.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import com.vishal.src.AnagramChecker;

import static junit.framework.Assert.*;

@RunWith(Parameterized.class)
public class TestAnagram {
	private String input1;
	private String input2;
	private boolean expected;
	private AnagramChecker anagramcheck;

	public TestAnagram(String input1, String input2, boolean expected) {
		super();
		this.input1 = input1;
		this.input2 = input2;
		this.expected = expected;
	}
	
	@Before
	public void init(){
		anagramcheck = new AnagramChecker();
	}
	
	@Parameterized.Parameters
	public static Collection anagramValue(){
		return Arrays.asList(new Object[][]{
			{"reactive", "creative", true},
			{"WORDIER", "WORRIED", true},
			{"todo", "ld", false},
			{"VOTE", "VETO", true},
			{"da", "data", false},
			{"commend", "welcome", false},
			{"", "yeild", false},
			{"Testing", "", false},
		});
	}
	
	@Test
	public void testAnagram(){
		System.out.println();
		System.out.println("test anagram here with inputs "+input1+" "+input2);
		assertEquals(expected, anagramcheck.checkAnagram(input1, input2));
	}

}
