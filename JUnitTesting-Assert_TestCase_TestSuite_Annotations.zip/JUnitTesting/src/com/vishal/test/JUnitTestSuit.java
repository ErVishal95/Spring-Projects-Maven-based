package com.vishal.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
	TestEmpBizLogic.class,
	TestPrimeNumberChecker.class,
	TestAnagram.class
})

public class JUnitTestSuit {

}
