package Service_TaxInvoice;

public interface Service_TaxInvoice {
	public void saveData();
}
