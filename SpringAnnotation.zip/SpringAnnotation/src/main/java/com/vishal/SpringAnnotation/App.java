package com.vishal.SpringAnnotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * This Maven Project is to Let us Understand the Spring Core Annotations.
 * This will show, How to Set Configuration with "Annotation" Only and not with "Configuration.xml" file
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext factory = new AnnotationConfigApplicationContext(AppConfig.class);
    	Samsung s7= factory.getBean(Samsung.class);
    	s7.config();

    }
}
