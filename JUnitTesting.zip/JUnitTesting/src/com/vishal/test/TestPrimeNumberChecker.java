package com.vishal.test;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import com.vishal.src.PrimeNumberChecker;

import static junit.framework.Assert.*;

@RunWith(Parameterized.class)
public class TestPrimeNumberChecker {
	private int inputNumber;
	private boolean expected;
	private PrimeNumberChecker primeNumberChecker;
	
	@Before
	public void init(){
		primeNumberChecker = new PrimeNumberChecker();
	}
	
	public TestPrimeNumberChecker(int inputNumber, boolean expected) {
		super();
		this.inputNumber = inputNumber;
		this.expected = expected;
	}
	
	@SuppressWarnings("rawtypes")
	@Parameterized.Parameters
	public static Collection primeNumbers(){
		return Arrays.asList(new Object[][]{
			{2, true},
			{5, true},
			{12, false},
			{13, true},
			{20, false},
			{43, true},
		});
	}
	
	@Test
	public void testPrimeNow(){
		System.out.println(inputNumber+" checking prime number with: "+inputNumber+" "+expected);
		assertEquals(expected, primeNumberChecker.checkPrimeNumber(inputNumber));
	}

}
