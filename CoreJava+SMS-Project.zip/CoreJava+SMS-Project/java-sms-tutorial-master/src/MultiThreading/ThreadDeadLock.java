package MultiThreading;

public class ThreadDeadLock {
	public static void main(String[] args) {
		final String resource1= "Core Java";
		final String resource2= "Advance Java";
		
		Thread t1 =  new Thread(){
			public void run(){
				synchronized (resource1) {
					System.out.println("Thread1 : Resource 1 Locked");
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					System.out.println("Thread1 : waiting for Resource 2 ");
				}
				synchronized (resource2) {
					System.out.println("Thread1 : Holding Resource 1 and 2 ");
					
				}
			}
		};
		Thread t2 =  new Thread(){
			public void run(){
				synchronized (resource2) {
					System.out.println("Thread2 : Resource 2 Locked");
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					System.out.println("Thread2 : waiting for Resource 1");
				}
				synchronized (resource1) {
					System.out.println("Thread2 : Holding Resource 1 and 2");
					
				}
			}
		};
		t1.start();
		t2.start();
	}

}
