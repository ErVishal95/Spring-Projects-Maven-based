package com.vishal.mail.service;

import com.vishal.mail.bean.Mail;

public interface MailService {
	public void sendEmail(Mail mail);
}
