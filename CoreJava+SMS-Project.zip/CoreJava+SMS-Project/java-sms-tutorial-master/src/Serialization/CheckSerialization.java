package Serialization;

import java.io.Serializable;

class CheckSerialization implements Serializable{
//This Example will help in understanding the concept of serialization 
//and the impact of transient, static and final keyword on object while object is going to be saved/persist to byte Stream
	
	/*int val1;
	static String lastNama;
	transient int val2;
	static transient int val3;*/
	int val1;
	static String lastNama = "Checklastname";
	transient int val2 = 58;
	static transient int val3 = 98;
}

class Test extends CheckSerialization{
	String firstName;
	private static final long serialVersionUID= 12L;
}
