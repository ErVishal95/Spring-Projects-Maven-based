package Modal_TaxInvoice;

import java.util.Date;

public class Product {
	private String description;
	private String hsncode;
	private float rate;
	private float qty;
	private float amount;
	private static String saleDate;
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getHsncode() {
		return hsncode;
	}
	public void setHsncode(String hsncode) {
		this.hsncode = hsncode;
	}
	public float getRate() {
		return rate;
	}
	public void setRate(float rate) {
		this.rate = rate;
	}
	public float getQty() {
		return qty;
	}
	public void setQty(float qty) {
		this.qty = qty;
	}
	
	//Calculating the Base amount of the Item
	public float getAmount() {
		amount = getRate()*getQty(); 
		return amount;
	}
	
	public String getSaleDate() {
		return saleDate;
	}
	public void setSaleDate(String saleDate) {
		this.saleDate = saleDate;
	}
	public Product(String description, String hsncode, double d, double e, String string) {
		super();
		this.description = description;
		this.hsncode = hsncode;
		this.rate = (float) d;
		this.qty = (float) e;
		this.saleDate = string;
	}
	public Product() {
		// TODO Auto-generated constructor stub
	}
	
	
}
