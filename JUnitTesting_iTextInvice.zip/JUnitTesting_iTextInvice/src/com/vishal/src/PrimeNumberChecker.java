package com.vishal.src;

public class PrimeNumberChecker {
	public boolean checkPrimeNumber(int pnum){
		if(pnum<=1){
			System.out.println("Not a Prime Number, less then 2");
		}
		else{
			for(int i=2; i<pnum; i++){
				if(pnum%i==0){
					return false;
				}
			}			
		}
		return true;
	}
}
