package com.vishal.SpringAnnotation;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration          // This Annotation makes this class as the Configuration file for AnnotationConfigApplicationContext class // 
@ComponentScan(basePackages="com.vishal.SpringAnnotation")    // This Annotation makes searching of objects (in classes having @Component Annotation) possible with in specified package, used along @Configuration Annotation //
public class AppConfig {
	
/*@Bean                			// This Annotation makes the object visible to getBean() method used along @Configuration Annotation//
	public Samsung getPhone()
	{
		return new Samsung();
	}
	@Bean
	public MobileProcessor getProcessor(){
		return new SnapDragon();
	}*/
}
