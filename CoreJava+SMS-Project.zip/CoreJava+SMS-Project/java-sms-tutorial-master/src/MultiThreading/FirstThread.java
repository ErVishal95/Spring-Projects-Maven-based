package MultiThreading;

public class FirstThread implements Runnable{
	
	public void run(){
		for(int i=0; i<4; i++){
			try {
				Thread.sleep(500);
				System.out.println(i);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public static void main(String[] args) throws InterruptedException {
		FirstThread ft= new FirstThread();
		Thread t1 = new Thread(ft);
		Thread t2 = new Thread(ft);
		Thread t3 = new Thread(ft);
		
		System.out.println(t1.getName()+" "+t1.getId());
		System.out.println(t2.getName()+" "+t2.getId());
		System.out.println(t3.getName()+" "+t3.getId());
		t1.setName("Vishal Verma");
		t3.setPriority(Thread.MAX_PRIORITY);
		System.out.println(t1.getName()+" "+t1.getId());
		
		t1.start();
		//t1.join(1100);
		
		t2.start();
		t3.start();
	}

}
