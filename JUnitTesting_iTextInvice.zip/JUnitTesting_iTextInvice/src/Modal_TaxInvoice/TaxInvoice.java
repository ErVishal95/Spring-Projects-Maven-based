package Modal_TaxInvoice;

import java.util.Date;

public class TaxInvoice {
	
	Product product = new Product();
	
	private String invoiceNum;
	private String invoiceDate;
	private  float subTotal;
	private  float discount;
	private  float cgstax;
	private  float sgstax;
	private  float g_total;
	
	
	public String getInvoiceNum() {
		return invoiceNum;
	}
	public void setInvoiceNum(String invoiceNum) {
		this.invoiceNum = invoiceNum;
	}
	public String getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public float getSubTotal() {
		/*subTotal+= product.getAmount();*/
		
		return subTotal;
	}
	
	public void setSubTotal(float subTotal) {
		//subTotal+= product.getAmount();
		System.out.println("Expected subtotal: "+subTotal);
		this.subTotal = subTotal;
	}
	
	public float getDiscount() {
		//discount = (float) ((product.getAmount()/100)*1.5);
		discount = (float) ((subTotal/100)*1.5);
		System.out.println(discount);
		return discount;
	}
	/*public void setDiscount(float discount) {
		this.discount = discount;
	}*/
	public float getCgstax() {
		cgstax = (float) ((subTotal/100)*1.5);
		
		return cgstax;
	}
	/*public void setCgstax(float cgstax) {
		this.cgstax = cgstax;
	}*/
	public float getSgstax() {
		sgstax = (float) ((subTotal/100)*1.5);
		
		return sgstax;
	}
/*	public void setSgstax(float sgstax) {
		this.sgstax = sgstax;
	}*/
	
	public float g_Total() {
		if(getSubTotal()>8000)
			g_total = getSubTotal()+getCgstax()+getSgstax()+getDiscount();
		else
			g_total = getSubTotal()+getCgstax()+getSgstax();
		return g_total;
	}
	public TaxInvoice(String invoiceNum, String invoiceDate, float subTotal, float discount, float cgstax,
			float sgstax,  float g_total) {
		super();
		this.invoiceNum = invoiceNum;
		this.invoiceDate = invoiceDate;
		this.subTotal = subTotal;
		this.discount = discount;
		this.cgstax = cgstax;
		this.sgstax = sgstax;
		this.g_total= g_total;
	}
	public TaxInvoice() {
		// TODO Auto-generated constructor stub
	}
	
	
	
}
